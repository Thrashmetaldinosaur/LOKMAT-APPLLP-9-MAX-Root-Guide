# APPLLP 7 Pro — Watchface Fahrenheit v2 (verified)

**User-confirmed working on 14 November 2026**, after one normal reboot, with native Fahrenheit in the OEM weather screens and correct Fahrenheit temperature on the watch face. The post-reboot Vector logs confirm the temperature hook ran (`6.0°C → 42.8°F` in memory). Future firmware updates and prolonged weather-refresh behavior have not yet been validated.

## Tested environment

- LOKMAT APPLLP 7 Pro (`WP_C30_VP69_OLED`), Android 15, firmware `LOKMAT_APPLLP_7_PRO_C30_EN_V1.0_20260921`.
- OEM launcher APK SHA-256: `d59e3d2ba375907ecf3ae2f95fccfa172e3fe2529d91037a211e150aa5e089f8`.
- Native 466×466 display at 182 DPI; Magisk and Vector (LSPosed-compatible bridge).
- OEM native Fahrenheit preference: `settings get system step_user_metric` = **`0`**. Changing it to `1` enables Celsius.
- Vector module package `com.appllp7.watchfacefahrenheit`, scoped **only** to `com.android.launcher3` (not the OEM weather app, system framework, or other packages).
- Compatible with the verified independent **Full First Page v1.6** launcher module in the same launcher scope.

## Why the module is needed

The OEM weather app uses the native `step_user_metric` switch for its Fahrenheit UI, but the stock watch-face/complication runtime hides temperature when it sees the imperial setting. Weather service `WeatherTemp` remains a raw Celsius value. Merely writing Fahrenheit into `WeatherTemp` did **not** restore the temperature, and a previous polling script was not a complete fix.

The module changes only the **launcher process' view** of `Settings.System.getString(..., "step_user_metric")` to the metric code path that displays temperature on faces. It hooks the OEM `SettingsProvider.getWeatherTemperature(ContentResolver)` method, whose actual return type is `float`, converting the Celsius float to Fahrenheit **in memory once**. It also hooks the `isMetric()` accessor. Other apps continue to read the actual `step_user_metric=0` Fahrenheit preference.

No OEM APK, database, global DPI, weather provider data, or Magisk service loop is modified. It requires a Vector reboot to activate. **Do not scope it to `com.wiite.watchweather`.**

## Build and install from sanitized source

Use JDK 17, Gradle 8.9 and Android SDK 35. The project includes compile-only Xposed stubs; the real hook implementation is loaded by Vector at runtime.

```powershell
gradle --no-daemon :app:assembleDebug
adb install -r .ppuild\outputspk\debugpp-debug.apk
```

Enable `APPLLP7 Watchface Fahrenheit v2` in Vector, scope to `com.android.launcher3` **only**, and reboot. Verify the native unit preference is `0`, check a weather-enabled watch face and the OEM weather app, and verify numeric temperature **and the unit symbol** are truly Fahrenheit. An `°C` suffix beside a Fahrenheit number is not a pass.

## Rollback

Disable **Watchface Fahrenheit** only in Vector and reboot. This does not uninstall or disable Full First Page v1.6. If you need a temporary Celsius baseline, `adb shell settings put system step_user_metric 1` changes OEM weather units too; re-enable native Fahrenheit with `... 0`.

## Release scope

This archive contains sanitized source, Gradle project and compile-only stubs. It intentionally excludes device-specific ADB serials, local Windows paths, personal diagnostic logs, APK pulls and private device backups. It is not a generic patch for other watch firmware.
