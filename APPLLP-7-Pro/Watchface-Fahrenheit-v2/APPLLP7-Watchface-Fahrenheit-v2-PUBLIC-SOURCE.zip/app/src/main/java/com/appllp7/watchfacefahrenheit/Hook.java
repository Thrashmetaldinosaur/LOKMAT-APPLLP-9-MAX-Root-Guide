package com.appllp7.watchfacefahrenheit;

import android.app.Application;
import android.content.Context;
import android.os.Build;
import android.provider.Settings;
import java.util.Set;
import java.util.concurrent.atomic.AtomicInteger;
import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

/**
 * Launcher-only experimental Fahrenheit compatibility for OEM watchfaces.
 * Respects native step_user_metric=0 for the separate Weather app process.
 * In the launcher process only, exposes the known-working metric code path
 * and converts the OEM FLOAT weather temperature in memory.
 * Does not modify any SettingsProvider database, firmware, or weather service.
 */
public final class Hook implements IXposedHookLoadPackage {
    private static final String PKG = "com.android.launcher3";
    private static final String BUILD = "LOKMAT_APPLLP_7_PRO_C30_EN_V1.0_20260921";
    private static final String PROVIDER = "com.wiite.support.watchface.runtime.SettingsProvider";
    private static final String KEY = "step_user_metric";
    private static volatile boolean registered;
    private static volatile Context app;
    private static final ThreadLocal<Boolean> rawRead = new ThreadLocal<Boolean>();
    private static final AtomicInteger getHits = new AtomicInteger();
    private static final AtomicInteger metricHits = new AtomicInteger();
    private static final AtomicInteger tempHits = new AtomicInteger();
    private static final AtomicInteger warnings = new AtomicInteger();

    private static void log(String t) { XposedBridge.log("APPLLP7FaceFv2: " + t); }
    private static boolean isActualF() {
        final Context c = app;
        if (c == null) return false;
        try {
            rawRead.set(Boolean.TRUE);
            return "0".equals(Settings.System.getString(c.getContentResolver(), KEY));
        } catch (Throwable t) { return false; }
        finally { rawRead.remove(); }
    }

    @Override public void handleLoadPackage(XC_LoadPackage.LoadPackageParam lp) {
        if (!PKG.equals(lp.packageName) || !BUILD.equals(Build.DISPLAY)) return;
        try {
            Set<?> attached=XposedBridge.hookAllMethods(Application.class, "attach", new XC_MethodHook() {
                @Override protected void afterHookedMethod(MethodHookParam p) {
                    if (registered) return;
                    try {
                        Context c=(Context)p.args[0];
                        if (c==null || !PKG.equals(c.getPackageName())) return;
                        app=c;
                        // Only the OEM launcher's own read of this exact units key
                        // is spoofed. Weather app and global value remain Fahrenheit.
                        Set<?> keyHooks=XposedBridge.hookAllMethods(Settings.System.class, "getString", new XC_MethodHook() {
                            @Override protected void afterHookedMethod(MethodHookParam h) {
                                if (Boolean.TRUE.equals(rawRead.get())) return;
                                if (h.args==null || h.args.length<2 || !KEY.equals(h.args[1])) return;
                                if ("0".equals(h.getResult())) {
                                    h.setResult("1");
                                    int n=getHits.incrementAndGet();
                                    if (n<=8) log("launcher-only unit getString read: native=0 spoofed=1 #"+n);
                                }
                            }
                        });
                        Class<?> cls=Class.forName(PROVIDER,false,c.getClassLoader());
                        Set<?> metric=XposedBridge.hookAllMethods(cls,"isMetric",new XC_MethodHook() {
                            @Override protected void afterHookedMethod(MethodHookParam h) {
                                if (!isActualF()) return;
                                if (!(h.getResult() instanceof Boolean)) return;
                                h.setResult(Boolean.TRUE);
                                int n=metricHits.incrementAndGet();
                                if(n<=8) log("isMetric callback: in-memory true #"+n);
                            }
                        });
                        // Verified DEX signature is FLOAT: getWeatherTemperature(ContentResolver):F.
                        // v1 erroneously expected Integer and therefore never converted it.
                        Set<?> temp=XposedBridge.hookAllMethods(cls,"getWeatherTemperature",new XC_MethodHook() {
                            @Override protected void afterHookedMethod(MethodHookParam h) {
                                if (!isActualF()) return;
                                Object result=h.getResult();
                                if (!(result instanceof Float)) {
                                    if (warnings.incrementAndGet()<=3)
                                        log("unexpected temperature return="+(result==null?"null":result.getClass().getName()));
                                    return;
                                }
                                float raw=(Float)result;
                                if (Float.isNaN(raw)||Float.isInfinite(raw)||raw< -70f||raw>60f) {
                                    if(warnings.incrementAndGet()<=3) log("out-of-range temperature="+raw+" unchanged");
                                    return;
                                }
                                float converted=(raw*9.0f/5.0f)+32.0f;
                                h.setResult(Float.valueOf(converted));
                                int n=tempHits.incrementAndGet();
                                if(n<=12) log("temperature Float callback " + n + ": " + raw + "C -> " + converted + "F in-memory");
                            }
                        });
                        log("hook counts: unitString="+(keyHooks==null?-1:keyHooks.size())+
                            " isMetric="+(metric==null?-1:metric.size())+
                            " temperatureFloat="+(temp==null?-1:temp.size()));
                        registered = keyHooks!=null&&!keyHooks.isEmpty()&&
                            metric!=null&&!metric.isEmpty()&&temp!=null&&!temp.isEmpty();
                        if(!registered) log("INCOMPLETE registration; test cannot pass");
                    } catch (Throwable t) { log("attach error: "+t.toString()); }
                }
            });
            log("launcher attach hook="+(attached==null?-1:attached.size()));
        } catch(Throwable e) { log("setup error: "+e.toString()); }
    }
}
