# APPLLP 7 Pro — Full First Page v1.7 (verified)

User-confirmed on 14 November 2026. OEM Style 5 has 10 regular icons per page, four original favorites, no clock/date widget, and no empty page at the wraparound boundary. Post-reboot Vector log confirms scroll requests -1 -> 9 and 10 -> 0 across 10 regular pages, while all 97 app-info drawables are present.

Exact tested firmware: LOKMAT_APPLLP_7_PRO_C30_EN_V1.0_20260921; device WP_C30_VP69_OLED; Android 15; 466x466 at native 182 DPI; stock launcher com.android.launcher3 SHA-256 d59e3d2ba375907ecf3ae2f95fccfa172e3fe2529d91037a211e150aa5e089f8. Requires root and Vector (LSPosed-compatible), module scope com.android.launcher3 only. Preserve other enabled modules such as Watchface Fahrenheit v2.

Source-only archive. To build: JDK 17, Android SDK 35, Gradle 8.9, Android Gradle plugin as declared in settings.gradle; run `gradle --no-daemon :app:assembleDebug`. For the exact verified firmware, install the built debug APK with `adb install -r app/build/outputs/apk/debug/app-debug.apk`, scope only to launcher in Vector, and reboot. Verify tapping and both swipe boundaries. No OEM APK, private launcher database, or global DPI writes.

Rollback: disable only APPLLP7 Full First Page in Vector and reboot to revert to stock page layout; for previous v1.6 specifically restore a retained signed v1.6 APK backup. Do not clear launcher data.

This archive omits installer scripts with local device identifiers, personal paths, and private diagnostic logs. Unverified on other firmware and devices.
