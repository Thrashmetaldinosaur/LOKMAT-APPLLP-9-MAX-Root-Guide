package com.appllp7.compact;

import android.app.Application;
import android.content.Context;
import android.content.res.Resources;
import android.os.Build;
import android.util.TypedValue;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.lang.reflect.Field;
import java.util.Set;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

/**
 * APPLLP7 Compact Notifications v3.
 * OEM notification-card-only adjustment. Never modifies the launcher APK,
 * system settings, other notifications, app data, or other Vector modules.
 * All view dimensions originate from the 2026-09-21 stock launcher APK.
 * Uses XposedBridge.hookAllMethods, which has been verified with this Vector
 * build, instead of the incompatible findAndHookMethod used in v1.
 */
public final class Hook implements IXposedHookLoadPackage {
    private static final String LAUNCHER = "com.android.launcher3";
    private static final String FIRMWARE = "LOKMAT_APPLLP_7_PRO_C30_EN_V1.0_20260921";
    private static final String ADAPTER = "com.android.launcher3.feature.notification.NotificationPanelAdapter";

    private static final int ROOT = 0x7f0a037d;     // layout-round-v23/item_notification.xml root
    private static final int MAIN_CARD = 0x7f0a0176; // FrameLayout; left unchanged
    private static final int TITLE = 0x7f0a044e;
    private static final int BODY = 0x7f0a042c;
    private static final int TIME = 0x7f0a044d;
    private static final int ICON = 0x7f0a01dd;
    private static final int ACTIONS = 0x7f0a024a;

    // Denser v3 profile; outer width and buttons remain unchanged.
    private static final float TITLE_SP = 14f;   // v2 18sp, OEM 28sp
    private static final float BODY_SP = 12f;    // v2 16sp, OEM 28sp
    private static final float TIME_SP = 10f;    // v2 11sp
    private static final int ICON_DP = 24;        // v2 32dp, OEM 48dp
    private static final int ROW_BOTTOM_DP = 2;  // v2 6dp, OEM 16dp
    private static final int TITLE_TOP_DP = 2;   // v2 6dp
    private static final int ICON_TOP_DP = 2;    // v2 4dp
    private static final int BODY_TOP_DP = 1;
    private static final int TIME_TOP_DP = 1;
    private static final int CARD_VERTICAL_PADDING_DP = 2;

    private static volatile boolean attached;
    private static volatile boolean hooked;
    private static volatile boolean seenRow;
    private static volatile boolean warned;

    @Override public void handleLoadPackage(final XC_LoadPackage.LoadPackageParam p) {
        if (!LAUNCHER.equals(p.packageName) || !LAUNCHER.equals(p.processName)) return;
        try {
            Set<?> attaches = XposedBridge.hookAllMethods(Application.class, "attach", new XC_MethodHook() {
                @Override protected void afterHookedMethod(MethodHookParam mp) {
                    if (hooked) return;
                    if (!(mp.args != null && mp.args.length > 0 && mp.args[0] instanceof Context)) return;
                    if (!FIRMWARE.equals(Build.DISPLAY)) {
                        warn("firmware guard failed: " + Build.DISPLAY, null);
                        return;
                    }
                    if (!attached) {
                        attached = true;
                        XposedBridge.log("APPLLP7CompactV3: launcher attach; resolving OEM adapter");
                    }
                    try {
                        Class<?> cls = Class.forName(ADAPTER, false, p.classLoader);
                        XC_MethodHook cb = new XC_MethodHook() {
                            @Override protected void afterHookedMethod(MethodHookParam parm) {
                                try {
                                    Object holder = parm.method.getName().equals("onCreateViewHolder")
                                        ? parm.getResult()
                                        : (parm.args != null && parm.args.length > 0 ? parm.args[0] : null);
                                    if (holder == null) return;
                                    // RecyclerView.ViewHolder exposes a public final itemView.
                                    Field f = holder.getClass().getField("itemView");
                                    Object view = f.get(holder);
                                    if (view instanceof View) compact((View) view);
                                } catch (Throwable e) {
                                    warn("row-hook failed", e);
                                }
                            }
                        };
                        Set<?> creates = XposedBridge.hookAllMethods(cls, "onCreateViewHolder", cb);
                        Set<?> binds = XposedBridge.hookAllMethods(cls, "onBindViewHolder", cb);
                        int nc = creates == null ? 0 : creates.size();
                        int nb = binds == null ? 0 : binds.size();
                        hooked = (nc + nb) > 0;
                        XposedBridge.log("APPLLP7CompactV3: hook registration create=" + nc +
                                         " bind=" + nb + " active=" + hooked);
                    } catch (Throwable e) {
                        warn("adapter hook registration failed", e);
                    }
                }
            });
            XposedBridge.log("APPLLP7CompactV3: Application.attach hook registered count=" +
                (attaches == null ? -1 : attaches.size()));
        } catch (Throwable e) {
            warn("Application.attach registration failed", e);
        }
    }

    private static int dp(View v, int n) {
        return Math.round(v.getResources().getDisplayMetrics().density * n);
    }

    private static void reduceTopMargin(View v, int topDp) {
        ViewGroup.LayoutParams lp = v.getLayoutParams();
        if (!(lp instanceof ViewGroup.MarginLayoutParams)) return;
        ViewGroup.MarginLayoutParams margins = (ViewGroup.MarginLayoutParams) lp;
        int target = dp(v, topDp);
        if (margins.topMargin > target) {
            margins.topMargin = target;
            v.setLayoutParams(margins);
        }
    }

    private static void reduceBottomMargin(View v, int bottomDp) {
        ViewGroup.LayoutParams lp = v.getLayoutParams();
        if (!(lp instanceof ViewGroup.MarginLayoutParams)) return;
        ViewGroup.MarginLayoutParams margins = (ViewGroup.MarginLayoutParams) lp;
        int target = dp(v, bottomDp);
        if (margins.bottomMargin > target) {
            margins.bottomMargin = target;
            v.setLayoutParams(margins);
        }
    }

    private static void trimCardVerticalPadding(View v, int padDp) {
        int target = dp(v, padDp);
        int top = Math.min(v.getPaddingTop(), target);
        int bottom = Math.min(v.getPaddingBottom(), target);
        if (top != v.getPaddingTop() || bottom != v.getPaddingBottom()) {
            // Preserve horizontal inset: important for a round 466x466 display.
            v.setPadding(v.getPaddingLeft(), top, v.getPaddingRight(), bottom);
        }
    }

    private static void compactText(TextView text, float sizeSp, int maxLines) {
        text.setTextSize(TypedValue.COMPLEX_UNIT_SP, sizeSp);
        text.setMaxLines(maxLines);
        // Removing font padding shrinks the actual TextView measured height.
        text.setIncludeFontPadding(false);
    }

    private static void compact(View itemView) {
        View title = itemView.findViewById(TITLE);
        View body = itemView.findViewById(BODY);
        View time = itemView.findViewById(TIME);
        View icon = itemView.findViewById(ICON);
        if (!(title instanceof TextView) || !(body instanceof TextView) || icon == null) return;
        // Verify this is specifically an OEM round notification card; do not
        // operate on a generic Android notification or another launcher view.
        View root = itemView.findViewById(ROOT);
        View card = itemView.findViewById(MAIN_CARD);
        if (root == null || card == null) return;
        compactText((TextView)title, TITLE_SP, 1);
        compactText((TextView)body, BODY_SP, 2);
        if (time instanceof TextView) {
            ((TextView)time).setTextSize(TypedValue.COMPLEX_UNIT_SP, TIME_SP);
            ((TextView)time).setIncludeFontPadding(false);
        }
        ViewGroup.LayoutParams iconParams = icon.getLayoutParams();
        if (iconParams != null) {
            int size = dp(icon, ICON_DP);
            if (iconParams.width != size || iconParams.height != size) {
                iconParams.width = size;
                iconParams.height = size;
                icon.setLayoutParams(iconParams);
            }
        }
        reduceTopMargin(icon, ICON_TOP_DP);
        reduceTopMargin(title, TITLE_TOP_DP);
        reduceTopMargin(body, BODY_TOP_DP);
        if (time != null) reduceTopMargin(time, TIME_TOP_DP);
        reduceBottomMargin(title, 1);
        reduceBottomMargin(body, 1);
        // Outer/root left-right padding remains unchanged to preserve round display insets.
        if (root instanceof ViewGroup) {
            int pad = dp(root, ROW_BOTTOM_DP);
            if (root.getPaddingBottom() > pad)
                root.setPadding(root.getPaddingLeft(), root.getPaddingTop(), root.getPaddingRight(), pad);
        }
        // Only cap existing vertical card padding; leave horizontal tap area intact.
        trimCardVerticalPadding(card, CARD_VERTICAL_PADDING_DP);
        // ACTIONS is intentionally left intact; no removal of buttons or any
        // notification, gesture or expansion handler. Card width untouched.
        if (!seenRow) {
            seenRow = true;
            XposedBridge.log("APPLLP7CompactV3: ROW_RESIZED: title=14sp body=12sp icon=24dp bottom=2dp; font padding removed, card vertical spacing capped; actions preserved");
        }
    }

    private static void warn(String msg, Throwable err) {
        if (warned) return;
        warned = true;
        XposedBridge.log("APPLLP7CompactV3: " + msg + (err == null ? "" : " (" + err.getClass().getSimpleName() + ")"));
    }
}
