# LOKMAT APPLLP 7 Pro — Compact Notifications (source bundle)

Includes two separate Android/Vector Xposed module projects:

- `v2-verified/`: **working baseline**, verified after installation/reboot with OEM notification row hook logs and visual PASS on the stock APPLLP 7 Pro firmware listed below. Targets title 18sp, message 16sp, icon 32dp and a maximum 6dp bottom inset.
- `v3-experimental/`: **denser version**, successfully built and installed in-place on the same watch, but the post-reboot ADB session disconnected and the visual/hook confirmation is **pending**. Targets title 14sp, message 12sp, icon 24dp and a maximum 2dp bottom inset. This uses the same application ID as v2 and versionCode 3.

These are the source projects, **not ready-to-install APKs**. The private test runners and watch diagnostics are intentionally omitted because they contain machine-specific details.

## Exact tested target

- Device: APPLLP 7 Pro (`WP_C30_VP69_OLED`), Android 15
- Firmware: `LOKMAT_APPLLP_7_PRO_C30_EN_V1.0_20260921`
- Launcher package: `com.android.launcher3` (stock OEM UI)
- Hook framework: Vector LSPosed variant; module scope should be **only** `com.android.launcher3`

This code uses hard-coded **OEM view resource IDs**. It is not portable across firmware revisions or other launcher packages. No fitness, battery, notification channel, application permission, or other Magisk modifications are made. The root and round-screen horizontal padding are left unchanged; notification action views are not intentionally modified.

## Build

Requirements: JDK 17, Android SDK platform 35, Android Gradle Plugin 8.7.3, Gradle 8.9, and the SDK license/build tools. From either project directory:

```powershell
gradle --no-daemon :app:assembleDebug
```

Build artifact: `app/build/outputs/apk/debug/app-debug.apk`. This is a locally signed **debug** build. To install or update while preserving an existing package, the signing certificate must match your installed copy. Do **not** uninstall a working module merely to bypass a signature mismatch. Back up first.

## Installation and rollback

1. Check device model and firmware with `adb shell getprop ro.product.device` and `adb shell getprop ro.build.display.id`. Confirm the exact values above before proceeding.
2. Back up any installed APK and module configuration first.
3. Install the matching, locally built APK using `adb install -r -t app/build/outputs/apk/debug/app-debug.apk`. An update to a differently signed module will fail, by design.
4. Enable **Compact Notifications** in Vector and scope **only** to `com.android.launcher3`; reboot.
5. Verify notification rendering, tappability, action buttons, and text clipping.

To reverse an unsuccessful visual change, disable only Compact Notifications in Vector and reboot. To downgrade from v3 to v2, reinstall a backed-up v2 APK **signed with the same certificate** (version downgrade may require `adb install -r -d -t`), then reboot. No stock launcher or system APK patch is involved.

## Privacy

Only share buildable source. No device serials, personal accounts, computer usernames, host paths, notifications, private logs, pairing codes, or signing keys are included.
