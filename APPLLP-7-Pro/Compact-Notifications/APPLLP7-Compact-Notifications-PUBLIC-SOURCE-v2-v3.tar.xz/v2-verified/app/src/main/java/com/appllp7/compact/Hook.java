package com.appllp7.compact;

import android.app.Application;
import android.content.Context;
import android.content.res.Resources;
import android.os.Build;
import android.util.TypedValue;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.lang.reflect.Field;
import java.util.Set;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

/**
 * APPLLP7 Compact Notifications v2.
 * OEM notification-card-only adjustment. Never modifies the launcher APK,
 * system settings, other notifications, app data, or other Vector modules.
 * All view dimensions originate from the 2026-09-21 stock launcher APK.
 * Uses XposedBridge.hookAllMethods, which has been verified with this Vector
 * build, instead of the incompatible findAndHookMethod used in v1.
 */
public final class Hook implements IXposedHookLoadPackage {
    private static final String LAUNCHER = "com.android.launcher3";
    private static final String FIRMWARE = "LOKMAT_APPLLP_7_PRO_C30_EN_V1.0_20260921";
    private static final String ADAPTER = "com.android.launcher3.feature.notification.NotificationPanelAdapter";

    private static final int ROOT = 0x7f0a037d;     // layout-round-v23/item_notification.xml root
    private static final int MAIN_CARD = 0x7f0a0176; // FrameLayout; left unchanged
    private static final int TITLE = 0x7f0a044e;
    private static final int BODY = 0x7f0a042c;
    private static final int TIME = 0x7f0a044d;
    private static final int ICON = 0x7f0a01dd;
    private static final int ACTIONS = 0x7f0a024a;

    // Moderate compact profile. Keep tappable outer width and action row intact.
    private static final float TITLE_SP = 18f;  // OEM 28sp
    private static final float BODY_SP = 16f;   // OEM 28sp
    private static final float TIME_SP = 11f;
    private static final int ICON_DP = 32;       // OEM 48dp
    private static final int ROW_BOTTOM_DP = 6; // OEM 16dp on the round layout
    private static final int TITLE_TOP_DP = 6;  // OEM 12dp
    private static final int ICON_TOP_DP = 4;

    private static volatile boolean attached;
    private static volatile boolean hooked;
    private static volatile boolean seenRow;
    private static volatile boolean warned;

    @Override public void handleLoadPackage(final XC_LoadPackage.LoadPackageParam p) {
        if (!LAUNCHER.equals(p.packageName) || !LAUNCHER.equals(p.processName)) return;
        try {
            Set<?> attaches = XposedBridge.hookAllMethods(Application.class, "attach", new XC_MethodHook() {
                @Override protected void afterHookedMethod(MethodHookParam mp) {
                    if (hooked) return;
                    if (!(mp.args != null && mp.args.length > 0 && mp.args[0] instanceof Context)) return;
                    if (!FIRMWARE.equals(Build.DISPLAY)) {
                        warn("firmware guard failed: " + Build.DISPLAY, null);
                        return;
                    }
                    if (!attached) {
                        attached = true;
                        XposedBridge.log("APPLLP7CompactV2: launcher attach; resolving OEM adapter");
                    }
                    try {
                        Class<?> cls = Class.forName(ADAPTER, false, p.classLoader);
                        XC_MethodHook cb = new XC_MethodHook() {
                            @Override protected void afterHookedMethod(MethodHookParam parm) {
                                try {
                                    Object holder = parm.method.getName().equals("onCreateViewHolder")
                                        ? parm.getResult()
                                        : (parm.args != null && parm.args.length > 0 ? parm.args[0] : null);
                                    if (holder == null) return;
                                    // RecyclerView.ViewHolder exposes a public final itemView.
                                    Field f = holder.getClass().getField("itemView");
                                    Object view = f.get(holder);
                                    if (view instanceof View) compact((View) view);
                                } catch (Throwable e) {
                                    warn("row-hook failed", e);
                                }
                            }
                        };
                        Set<?> creates = XposedBridge.hookAllMethods(cls, "onCreateViewHolder", cb);
                        Set<?> binds = XposedBridge.hookAllMethods(cls, "onBindViewHolder", cb);
                        int nc = creates == null ? 0 : creates.size();
                        int nb = binds == null ? 0 : binds.size();
                        hooked = (nc + nb) > 0;
                        XposedBridge.log("APPLLP7CompactV2: hook registration create=" + nc +
                                         " bind=" + nb + " active=" + hooked);
                    } catch (Throwable e) {
                        warn("adapter hook registration failed", e);
                    }
                }
            });
            XposedBridge.log("APPLLP7CompactV2: Application.attach hook registered count=" +
                (attaches == null ? -1 : attaches.size()));
        } catch (Throwable e) {
            warn("Application.attach registration failed", e);
        }
    }

    private static int dp(View v, int n) {
        return Math.round(v.getResources().getDisplayMetrics().density * n);
    }

    private static void reduceTopMargin(View v, int topDp) {
        ViewGroup.LayoutParams lp = v.getLayoutParams();
        if (!(lp instanceof ViewGroup.MarginLayoutParams)) return;
        ViewGroup.MarginLayoutParams margins = (ViewGroup.MarginLayoutParams) lp;
        int target = dp(v, topDp);
        if (margins.topMargin > target) {
            margins.topMargin = target;
            v.setLayoutParams(margins);
        }
    }

    private static void compact(View itemView) {
        View title = itemView.findViewById(TITLE);
        View body = itemView.findViewById(BODY);
        View time = itemView.findViewById(TIME);
        View icon = itemView.findViewById(ICON);
        if (!(title instanceof TextView) || !(body instanceof TextView) || icon == null) return;
        // Verify this is specifically an OEM round notification card; do not
        // operate on a generic Android notification or another launcher view.
        View root = itemView.findViewById(ROOT);
        View card = itemView.findViewById(MAIN_CARD);
        if (root == null || card == null) return;
        ((TextView)title).setTextSize(TypedValue.COMPLEX_UNIT_SP, TITLE_SP);
        ((TextView)body).setTextSize(TypedValue.COMPLEX_UNIT_SP, BODY_SP);
        ((TextView)title).setMaxLines(1); // original 2; truncation is UI-only
        ((TextView)body).setMaxLines(2);  // original 3; tap still opens app
        if (time instanceof TextView) ((TextView)time).setTextSize(TypedValue.COMPLEX_UNIT_SP, TIME_SP);
        ViewGroup.LayoutParams iconParams = icon.getLayoutParams();
        if (iconParams != null) {
            int size = dp(icon, ICON_DP);
            if (iconParams.width != size || iconParams.height != size) {
                iconParams.width = size;
                iconParams.height = size;
                icon.setLayoutParams(iconParams);
            }
        }
        reduceTopMargin(icon, ICON_TOP_DP);
        reduceTopMargin(title, TITLE_TOP_DP);
        if (root instanceof ViewGroup) {
            int pad = dp(root, ROW_BOTTOM_DP);
            if (root.getPaddingBottom() > pad)
                root.setPadding(root.getPaddingLeft(), root.getPaddingTop(), root.getPaddingRight(), pad);
        }
        // ACTIONS is intentionally left intact; no removal of buttons or any
        // notification, gesture or expansion handler. Card width untouched.
        if (!seenRow) {
            seenRow = true;
            XposedBridge.log("APPLLP7CompactV2: ROW_RESIZED: title=18sp body=16sp icon=32dp bottom=6dp; actions preserved");
        }
    }

    private static void warn(String msg, Throwable err) {
        if (warned) return;
        warned = true;
        XposedBridge.log("APPLLP7CompactV2: " + msg + (err == null ? "" : " (" + err.getClass().getSimpleName() + ")"));
    }
}
