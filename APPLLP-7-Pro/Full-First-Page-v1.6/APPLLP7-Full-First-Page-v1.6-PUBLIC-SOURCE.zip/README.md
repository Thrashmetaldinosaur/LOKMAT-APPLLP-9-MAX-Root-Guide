# APPLLP 7 Pro Full First Page v1.6 — user-confirmed working

On the tested LOKMAT APPLLP 7 Pro running Android 15 (firmware `LOKMAT_APPLLP_7_PRO_C30_EN_V1.0_20260921`), the native Style 5 paged app drawer can show **10 normal app icons (5 × 2) plus the original four dock favorites** on the first page, with the oversized clock/date removed.

**Status:** User-confirmed visual result 14 Nov 2026 after installation, Vector reload/reboot, and screenshot. The existing app order and dock favorites were preserved. Other firmware variants are not tested.

## Mechanism

This is a Vector/LSPosed Xposed module scoped **only to `com.android.launcher3`**. The stock launcher `MtkLauncher3QuickStep.apk` uses a dynamically loaded `MobilePagedAllAppsBoard`, so hooks installed through the parent's class loader alone will not reach the live renderer. v1.6 discovers the runtime board through `AllAppsBoardFactory.create` and the OEM renderer setter, then patches the live renderer's first-page geometry. It keeps the first four indices in their OEM dock positions; remaining icons use the native 5 × 2 grid. The clock/date drawing alone is suppressed.

## Compatibility and safety

- Test model: `WP_C30_VP69_OLED` (LOKMAT APPLLP 7 Pro / `DW Watch`).
- Android: 15; specified firmware only; native physical display density: **182**.
- Requires Magisk root and a compatible Vector/LSPosed installation.
- OEM app menu style 5 (`settings get system app_list_style`).
- OEM launcher APK not modified, replaced, or signed; no launcher app-order database changes.
- Only enable the Xposed module for `com.android.launcher3`.
- **Rollback:** disable **APPLLP7 Full First Page** in Vector, then reboot. Do not clear the OEM launcher app data.

## Build

Requires Android SDK Platform 35, JDK 17 and Gradle 8.9 compatible with Android Gradle Plugin 8.7.3. Run from this archive's root:

```powershell
gradle --no-daemon :app:assembleDebug
```

APK output: `app/build/outputs/apk/debug/app-debug.apk`. Install with authorized ADB:

```powershell
adb devices
adb install -r .\app\build\outputs\apk\debug\app-debug.apk
```

Enable the module in Vector, scoped **launcher only**, then reboot. Confirm the first page has 10 icons plus the four unchanged favorites. Check tapping and page swipes. Disable the module if misaligned.

The source uses compile-time stub classes under `stubs/` for Xposed; Vector provides the actual runtime Xposed bridge. This source package has **no device-specific serials, logs, backup images, or private files**.

## Diagnostic history

- v1.0–v1.3: hooks never reached the live renderer (early API/signature and classloader issues).
- v1.4: custom class loader was correctly reached; readiness guard prevented grid changes.
- v1.5: enlarged grid and removed clock/date, but lost the original dock favorites.
- **v1.6: user-confirmed on-screen result with 10 icons plus four favorites and no clock/date.**
