package de.robv.android.xposed;
import java.util.Set;
public final class XposedBridge {
  public static Set<?> hookAllMethods(Class<?> c, String name, XC_MethodHook cb) { return null; }
  public static void log(String msg) { }
  public static void log(Throwable t) { }
}
