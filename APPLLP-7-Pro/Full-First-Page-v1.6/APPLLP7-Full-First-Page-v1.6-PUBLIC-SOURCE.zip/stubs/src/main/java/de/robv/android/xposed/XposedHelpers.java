package de.robv.android.xposed;
public final class XposedHelpers {
  public static Class<?> findClass(String n, ClassLoader cl) { return null; }
  public static Object callMethod(Object o, String n, Object... a) { return null; }
  public static Object getObjectField(Object o, String n) { return null; }
  public static Object findAndHookMethod(Class<?> c, String n, Object... params) { return null; }
}
