package com.appllp7.fullfirstpage;

import android.app.Application;
import android.content.Context;
import android.graphics.RectF;
import android.graphics.Canvas;
import android.os.Build;
import android.os.SystemClock;
import android.provider.Settings;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.Member;
import java.util.Set;
import java.util.List;
import java.lang.ThreadLocal;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

/**
 * Reversible first-page-only geometry adjustment for ONE OEM launcher build.
 *
 * The OEM's MobilePagedAllAppsBoard uses four initial favorites with a
 * dedicated bottom dock and a manually drawn clock/date. The remaining apps
 * use the native 5x2 grid. This hook retains those four favorites in their
 * original hit geometry and moves only the remaining apps to a full first page.
 * It does not scale icons,
 * replace the launcher, modify app ordering, or install a background service.
 *
 * This is a first hardware trial. User must enable in Vector scoped solely to
 * com.android.launcher3, inspect taps and swipes, and retain rollback ability.
 */
public final class Hook implements IXposedHookLoadPackage {
    private static final String TARGET = "com.android.launcher3";
    private static final String BOARD = "com.android.launcher3.feature.allapps.list2d.MobilePagedAllAppsBoard";
    private static final String FIRMWARE = "LOKMAT_APPLLP_7_PRO_C30_EN_V1.0_20260921";
    private static final float PAGE = 200.0f; // OEM page width
    private static final int OEM_FAVORITES = 4; // verified native first-page dock count

    private static volatile boolean installed;
    private static volatile boolean hooksValid = true;
    private static volatile boolean hookSetupComplete;
    private static volatile boolean ready;
    private static volatile boolean loggedGrid;
    private static volatile boolean loggedClock;
    private static volatile boolean loggedError;
    private static volatile boolean loggedPending;
    private static volatile boolean loggedAttached;
    private static volatile boolean loggedDraw;
    private static volatile boolean loggedTarget;
    private static volatile boolean loggedTimeCallback;
    private static volatile boolean loggedPinned;
    private static volatile boolean loggedRegular;
    private static final ThreadLocal<Integer> mappedPositionIndex = new ThreadLocal<>();
    private static final ThreadLocal<Integer> mappedPageIndex = new ThreadLocal<>();
    private static volatile long lastEnsureAttempt;
    private static Method appInfoMethod;
    private static Method drawableMethod;
    private static Method resetDrawablePositions;
    private static Field colField;
    private static Field rowField;
    private static volatile boolean pendingDrawableReset;
    private static volatile String lastSnapshot = "";
    private static volatile long lastSnapshotTime;

    private static Field firstField;
    private static Field normalField;
    private static Field totalField;
    private static Field limitUpField;
    private static Field limitDownField;
    private static Field currentPageField;
    private static Field cameraPosField;
    private static Field cameraCenterField;
    private static Field widgetBgField;
    private static Field dockTopField;
    private static Field dockBottomField;
    private static Field dockLeftField;
    private static Field dockRightField;

    private static volatile boolean loggedDifferentBoard;
    private static volatile boolean loggedFactory;
    private static volatile boolean loggedSetter;

    @Override public void handleLoadPackage(XC_LoadPackage.LoadPackageParam p) {
        if (!TARGET.equals(p.packageName) || !TARGET.equals(p.processName)) return;
        try {
            XposedBridge.hookAllMethods(Application.class, "attach", new XC_MethodHook() {
                @Override protected void afterHookedMethod(MethodHookParam mp) {
                    if (loggedAttached) return;
                    try {
                        Context ctx = (Context) mp.args[0];
                        if (!FIRMWARE.equals(Build.DISPLAY)) return;
                        if (Settings.System.getInt(ctx.getContentResolver(), "app_list_style", -1) != 5) return;
                        loggedAttached = true;
                        XposedBridge.log("APPLLP7FullGridV16: Application.attach; installing factory hooks using parent class loader");
                        final ClassLoader parentLoader = p.classLoader;
                        Class<?> factory = Class.forName(
                            "com.android.launcher3.feature.allapps.AllAppsBoardFactory", false, parentLoader);
                        verifiedFactoryHook(factory, "create", new XC_MethodHook() {
                            @Override protected void afterHookedMethod(MethodHookParam par) {
                                if (!loggedFactory) {
                                    loggedFactory = true;
                                    Object result=par.getResult();
                                    XposedBridge.log("APPLLP7FullGridV16: factory.create invoked; returned="+
                                        (result==null?"null":result.getClass().getName()));
                                }
                                try { installLiveBoardHooks(par.getResult(), parentLoader); }
                                catch (Throwable t) { warn("factory callback",t); }
                            }
                        });
                        // Secondary capture path if the factory invocation was inlined.
                        Class<?> render = Class.forName(
                            "com.android.launcher3.feature.allapps.AbsAllAppsContentRenderUnity",false,parentLoader);
                        verifiedFactoryHook(render,"setMAllAppsBoard",new XC_MethodHook() {
                            @Override protected void afterHookedMethod(MethodHookParam par) {
                                if (!loggedSetter) {
                                    loggedSetter = true;
                                    Object result=par.args.length>0?par.args[0]:null;
                                    XposedBridge.log("APPLLP7FullGridV16: setMAllAppsBoard invoked; board="+
                                      (result==null?"null":result.getClass().getName()));
                                }
                                try { if(par.args.length>0)installLiveBoardHooks(par.args[0],parentLoader); }
                                catch(Throwable t) { warn("setMAllAppsBoard callback",t); }
                            }
                        });
                        deoptKnownCaller(parentLoader,
                            "com.android.launcher3.feature.allapps.AbsAllAppsContentRenderUnity", "initAppsBoard");
                        XposedBridge.log("APPLLP7FullGridV16: factory/renderer capture registered; awaiting concrete board");
                    } catch(Throwable t) { warn("factory hook init",t); }
                }
            });
        } catch(Throwable t) { warn("attach",t); }
    }

    private static void verifiedFactoryHook(Class<?> c,String name,XC_MethodHook hook) {
        Set<?> s = XposedBridge.hookAllMethods(c,name,hook);
        boolean ok = s!=null && !s.isEmpty() && !s.contains(null);
        XposedBridge.log("APPLLP7FullGridV16: parent hook "+c.getSimpleName()+"."+name+
            " count="+(s==null?-1:s.size())+" valid="+ok);
        if(!ok) warn("parent hook "+name,new IllegalStateException("Vector hook registration returned zero"));
    }

    // Deoptize the ACTUAL dynamic subclass, never a duplicate Class object.
    private static void deoptClassCaller(Class<?> cls,String method) {
        try {
            Method api=XposedBridge.class.getDeclaredMethod("deoptimizeMethod",Member.class);
            api.setAccessible(true);
            int count=0;
            for (Method m:cls.getDeclaredMethods()) if(m.getName().equals(method)) {
                m.setAccessible(true); api.invoke(null,m); count++;
            }
            XposedBridge.log("APPLLP7FullGridV16: deopt concrete "+method+" count="+count);
        } catch(Throwable t) { XposedBridge.log("APPLLP7FullGridV16: concrete deopt "+method+" unavailable: "+t); }
    }

    private static void installLiveBoardHooks(Object board, ClassLoader parentLoader) {
        if (board == null || installed) return;
        synchronized (Hook.class) {
            if (installed) return;
            Class<?> c = board.getClass();
            String actual = c.getName();
            if (!BOARD.equals(actual)) {
                if (!loggedDifferentBoard) {
                    loggedDifferentBoard = true;
                    XposedBridge.log("APPLLP7FullGridV16: actual renderer is "+actual+"; not the expected Style 5 board; leaving stock layout");
                }
                return;
            }
            try {
                Class<?> parentCopy = Class.forName(BOARD, false, parentLoader);
                XposedBridge.log("APPLLP7FullGridV16: runtime board identified; concreteClassLoader="+
                    c.getClassLoader().getClass().getName()+"; sameAsParentClass="+(c==parentCopy));
                            // Fail closed: resolve ALL required private members and methods
                            // before registering any Xposed hooks.
                            // Resolve inherited app-info accessor without depending on
                            // Vector's XposedHelpers.callMethod() bridge signature.
                            appInfoMethod = inheritedZeroArg(c, "getAppInfoList");
                            drawableMethod = inheritedZeroArg(c, "getMAllAppsDrawableList");
                            resetDrawablePositions = c.getDeclaredMethod("resetDrawArrayPos");
                            resetDrawablePositions.setAccessible(true);
                            colField = field(c, "mColCount");
                            rowField = field(c, "mRowCount");
                            firstField = field(c, "mPage1AppCount");
                            normalField = field(c, "mNormalPageAppCount");
                            totalField = field(c, "mTotalPages");
                            limitUpField = field(c, "mLimitLookUp");
                            limitDownField = field(c, "mLimitLookDown");
                            currentPageField = field(c, "mCurrentPage");
                            cameraPosField = field(c, "mCameraPos");
                            cameraCenterField = field(c, "mCameraCenter");
                            widgetBgField = field(c, "mWidgetBgRect");
                            dockTopField = field(c, "mDockBgTopRatio");
                            dockBottomField = field(c, "mDockBgBottomRatio");
                            dockLeftField = field(c, "mDockBgLeftRatio");
                            dockRightField = field(c, "mDockBgRightRatio");
                            c.getDeclaredMethod("getTargetPosForIndex", int.class, float[].class);
                            c.getDeclaredMethod("getPageIndexForApp", int.class);
                            c.getDeclaredMethod("drawTimeWidget", Canvas.class);
                            c.getDeclaredMethod("createDrawables");
                            c.getDeclaredMethod("draw", Canvas.class, float.class, float.class);
                            c.getDeclaredMethod("buildAllAppsDrawable", float.class, float.class);

                            XposedBridge.log("APPLLP7FullGridV16: target methods and fields resolved; registering hooks");
                            // Called by OEM after page counts and orientation layout are set,
                            // immediately BEFORE it creates the actual app drawable positions.
                            verifiedHook(c, "createDrawables", new XC_MethodHook() {
                                @Override protected void beforeHookedMethod(MethodHookParam par) {
                                    try {
                                        if (!hookSetupComplete || !hooksValid) return;
                                        ready = applyPageCounts(par.thisObject);
                                        if (!ready && !loggedPending) {
                                            loggedPending = true;
                                            XposedBridge.log("APPLLP7FullGridV16: app list unavailable at createDrawables; leaving stock geometry intact");
                                        }
                                    } catch (Throwable t) { ready=false; warn("createDrawables",t); }
                                }
                            });
                            verifiedHook(c, "buildAllAppsDrawable", new XC_MethodHook() {
                                @Override protected void afterHookedMethod(MethodHookParam par) {
                                    try { if (hookSetupComplete && hooksValid) ready = applyPageCounts(par.thisObject); }
                                    catch (Throwable t) { warn("rebuild",t); }
                                }
                            });
                            // The OEM's first FOUR apps are the favorites/dock, NOT expendable
                            // placeholders. Leave their native position, label and hit geometry alone.
                            // Only apps at index >=4 are remapped to a 10-icon page starting at 0.
                            verifiedHook(c, "getTargetPosForIndex", new XC_MethodHook() {
                                @Override protected void beforeHookedMethod(MethodHookParam par) {
                                    if (!loggedTarget) { loggedTarget=true;
                                        XposedBridge.log("APPLLP7FullGridV16: getTargetPosForIndex callback invoked"); }
                                    if (!ensureReady(par.thisObject, "position")) return;
                                    if (!(par.args[0] instanceof Integer)) return;
                                    int idx=(Integer) par.args[0];
                                    if (idx < 0) return;
                                    if (idx < OEM_FAVORITES) {
                                        if (!loggedPinned) { loggedPinned=true;
                                            XposedBridge.log("APPLLP7FullGridV16: native 4 favorite positions retained"); }
                                        return;  // original OEM bottom-dock coordinates, no translation
                                    }
                                    try {
                                        // Translate only regular app indices. OEM mPage1AppCount
                                        // remains FOUR outside this exact method invocation.
                                        firstField.setInt(par.thisObject, 0);
                                        mappedPositionIndex.set(idx);
                                        par.args[0] = idx - OEM_FAVORITES;
                                        if (!loggedRegular) { loggedRegular=true;
                                            XposedBridge.log("APPLLP7FullGridV16: grid starts after 4 favorites; app index 4 maps to grid index 0"); }
                                    } catch (Throwable t) {
                                        try { firstField.setInt(par.thisObject, OEM_FAVORITES); } catch(Throwable ignored) { }
                                        mappedPositionIndex.remove();
                                        warn("position pre", t);
                                    }
                                }
                                @Override protected void afterHookedMethod(MethodHookParam par) {
                                    Integer original=mappedPositionIndex.get();
                                    if (original==null) return;
                                    mappedPositionIndex.remove();
                                    try {
                                        // The OEM's regular-page world coordinates include the
                                        // original reserved first-page world width.
                                        float[] out = (float[]) par.args[1];
                                        if (out != null && out.length >= 2) out[0] -= PAGE;
                                    } catch(Throwable t) { warn("position post", t); }
                                    finally {
                                        par.args[0]=original;
                                        try { firstField.setInt(par.thisObject, OEM_FAVORITES); }
                                        catch(Throwable t) { warn("position restore", t); }
                                    }
                                }
                            });
                            verifiedHook(c, "getPageIndexForApp", new XC_MethodHook() {
                                @Override protected void beforeHookedMethod(MethodHookParam par) {
                                    if (!ensureReady(par.thisObject, "page")) return;
                                    if (!(par.args[0] instanceof Integer)) return;
                                    int idx=(Integer) par.args[0];
                                    if (idx < OEM_FAVORITES) return; // dock stays on page 0
                                    try {
                                        firstField.setInt(par.thisObject, 0);
                                        mappedPageIndex.set(idx);
                                        par.args[0]=idx - OEM_FAVORITES;
                                    } catch(Throwable t) {
                                        try { firstField.setInt(par.thisObject, OEM_FAVORITES); } catch(Throwable ignored) { }
                                        mappedPageIndex.remove();
                                        warn("page pre", t);
                                    }
                                }
                                @Override protected void afterHookedMethod(MethodHookParam par) {
                                    Integer original=mappedPageIndex.get();
                                    if(original==null) return;
                                    mappedPageIndex.remove();
                                    try {
                                        Object ret=par.getResult();
                                        if(ret instanceof Integer && (Integer)ret>=1)
                                            par.setResult(((Integer)ret)-1);
                                    } catch(Throwable t) { warn("page post",t); }
                                    finally {
                                        par.args[0]=original;
                                        try { firstField.setInt(par.thisObject, OEM_FAVORITES); }
                                        catch(Throwable t) { warn("page restore", t); }
                                    }
                                }
                            });
                            // Unlike the clock's custom Canvas draw call, this suppresses
                            // time/date, backgrounds and the associated old clock hitbox.
                            verifiedHook(c, "drawTimeWidget", new XC_MethodHook() {
                                    @Override protected void beforeHookedMethod(MethodHookParam par) {
                                        if (!loggedTimeCallback) { loggedTimeCallback=true;
                                            XposedBridge.log("APPLLP7FullGridV16: drawTimeWidget callback invoked"); }
                                        if (!ensureReady(par.thisObject, "clock")) return;
                                        try {
                                            RectF old = (RectF) widgetBgField.get(par.thisObject);
                                            if (old != null) old.setEmpty();
                                        } catch (Throwable t) { warn("clock hitbox",t); }
                                        if (!loggedClock) {
                                            loggedClock=true;
                                            XposedBridge.log("APPLLP7FullGridV16: first-page time/date widget suppressed");
                                        }
                                        par.setResult(null);
                                    }
                                });
                            verifiedHook(c, "draw", new XC_MethodHook() {
                                @Override protected void beforeHookedMethod(MethodHookParam par) {
                                    if (!loggedDraw) { loggedDraw=true;
                                        XposedBridge.log("APPLLP7FullGridV16: draw callback invoked"); }
                                    if (!ensureReady(par.thisObject, "draw")) return;
                                    try {
                                        if (pendingDrawableReset) {
                                            pendingDrawableReset=false; // mark first to avoid reentrant position recalculation
                                            resetDrawablePositions.invoke(par.thisObject);
                                            XposedBridge.log("APPLLP7FullGridV16: drawable positions recalculated using full-grid coordinates");
                                        }
                                        // PRESERVE all four OEM dock geometry fields and
                                        // its background. Only the clock widget is suppressed.
                                        RectF widget = (RectF) widgetBgField.get(par.thisObject);
                                        if (widget != null) widget.setEmpty();
                                    } catch (Throwable t) { warn("clock background",t); }
                                }
                            });
                            // The OEM DEX shows the real call graph:
                            // View2D.onDraw -> ContentRenderUnity.onDrawFrame -> Board.draw
                            // -> drawTimeWidget/getTargetPosForIndex. ART may inline these
                            // calls and skip an otherwise valid legacy Xposed trampoline.
                            // Deoptimize ONLY these callers; never system_server or Android
                            // global rendering. Report whether Vector exposes this API.
                            deoptKnownCaller(parentLoader,
                                "com.android.launcher3.feature.allapps.AbsAllAppsContentViewUnity$View2D", "onDraw");
                            deoptKnownCaller(parentLoader,
                                "com.android.launcher3.feature.allapps.AbsAllAppsContentRenderUnity", "onDrawFrame");
                            deoptClassCaller(c, "draw");
                            deoptClassCaller(c, "buildAllAppsDrawable");
                            hookSetupComplete = true;
                            installed = true;
                            XposedBridge.log("APPLLP7FullGridV16: OEM hook registration complete; valid="+hooksValid+"; await draw/clock callbacks");
            } catch (Throwable t) {
                warn("runtime board hook installation", t);
            }
        }
    }

    // A drawable build can occur before the hook is attached. The OEM's draw
    // path runs for every visible App Menu frame, so this performs a bounded,
    // throttled recheck from live rendering instead of only at createDrawables.
    // Do not touch geometry until all reflection and nonempty app-list guards pass.
    private static boolean ensureReady(Object board,String phase) {
        if (!hookSetupComplete || !hooksValid) return false;
        if (ready) return true;
        long now = SystemClock.uptimeMillis();
        if (now-lastEnsureAttempt < 1600L) return false;
        lastEnsureAttempt = now;
        try {
            ready=applyPageCounts(board);
            if (!ready && !loggedPending) {
                loggedPending=true;
                XposedBridge.log("APPLLP7FullGridV16: "+phase+" callback reached, but app list/grid not ready; stock layout retained");
            }
            return ready;
        } catch (Throwable t) {
            warn("ensureReady "+phase,t);
            return false;
        }
    }

    private static Method inheritedZeroArg(Class<?> c, String name) throws Exception {
        for (Class<?> next = c; next != null; next = next.getSuperclass()) {
            try {
                Method method = next.getDeclaredMethod(name);
                method.setAccessible(true);
                return method;
            } catch (NoSuchMethodException ignored) { }
        }
        throw new NoSuchMethodException(name);
    }

    private static Field field(Class<?> c,String name) throws Exception {
        Field f=c.getDeclaredField(name);
        f.setAccessible(true);
        return f;
    }
    /**
     * OEM buildAllAppsDrawable() chooses EITHER a 10-item (5x2) OR 12-item
     * (4x3/3x4) page based on orientation/configuration. Never assume 12.
     * Do not infer a count from the persistent launcher SQLite database.
     * Inspect the live board's own app-info AND drawable lists instead.
     * Fail closed when the live grid or inventory is unexpected.
     */
    private static boolean applyPageCounts(Object board) throws Exception {
        int normal=normalField.getInt(board);
        int col=colField.getInt(board);
        int row=rowField.getInt(board);
        int first=firstField.getInt(board);
        Object source=appInfoMethod.invoke(board);
        Object drawableSource=drawableMethod.invoke(board);
        int apps=(source instanceof List)?((List<?>)source).size():-1;
        int drawables=(drawableSource instanceof List)?((List<?>)drawableSource).size():-1;
        long now=SystemClock.uptimeMillis();
        String state="normal="+normal+" grid="+col+"x"+row+" first="+first+
            " appInfos="+apps+" drawables="+drawables;
        if(!state.equals(lastSnapshot) && now-lastSnapshotTime>1500L) {
            lastSnapshot=state;
            lastSnapshotTime=now;
            XposedBridge.log("APPLLP7FullGridV16: live board state: "+state);
        }
        // Both page capacities were verified in the stock classes6.dex.
        // Full grid cannot be inferred from the number 12 alone.
        if((normal!=10 && normal!=12) || col<=0 || row<=0 || col*row!=normal) return false;
        if(first!=OEM_FAVORITES) return false; // preserve four OEM favorites
        if(apps<normal+OEM_FAVORITES && drawables<normal+OEM_FAVORITES) return false;
        if(apps>300 || drawables>300) return false;
        int count=(apps>=normal)?apps:drawables;
        if(count<normal+OEM_FAVORITES || count>300) return false;
        // First 4 are always favorites. Only the remaining apps are paged.
        int pages=Math.max(1,(count-OEM_FAVORITES+normal-1)/normal);
        if(!ready) pendingDrawableReset=true;
        // DO NOT replace mPage1AppCount with 0: that removes the OEM dock.
        firstField.setInt(board,OEM_FAVORITES);
        totalField.setInt(board,pages);
        limitUpField.setFloat(board,PAGE*(pages-1));
        limitDownField.setFloat(board,0f);
        int current=currentPageField.getInt(board);
        if(current>=pages) currentPageField.setInt(board,pages-1);
        clampCamera(cameraPosField.get(board),pages);
        clampCamera(cameraCenterField.get(board),pages);
        if(!loggedGrid) {
            loggedGrid=true;
            XposedBridge.log("APPLLP7FullGridV16: OEM FULL GRID ACTIVE: "+state+
                " selectedCount="+count+" pages="+pages+" favoriteCount="+OEM_FAVORITES+
                " regularAppsPerPage="+normal);
        }
        return true;
    }
    private static void clampCamera(Object vec,int pages) {
        if(vec==null)return;
        try {
            Field x=vec.getClass().getField("x");
            float val=x.getFloat(vec);
            float end=PAGE*(pages-1);
            if(val<0) x.setFloat(vec,0f);
            if(val>end) x.setFloat(vec,end);
        } catch(Throwable ignored) { }
    }

    // Unlike the earlier misleading "registered" log, report return values from
    // Vector's native hook registration. Set(null) can mean native hook failure.
    private static void verifiedHook(Class<?> cls,String method,XC_MethodHook callback) {
        try {
            Set<?> hooks=XposedBridge.hookAllMethods(cls,method,callback);
            int count=hooks==null ? -1 : hooks.size();
            boolean failed=(hooks==null || hooks.isEmpty() || hooks.contains(null));
            XposedBridge.log("APPLLP7FullGridV16: register "+cls.getSimpleName()+"."+method+
                " count="+count+" failed="+failed);
            if(failed) hooksValid=false;
        } catch(Throwable t) {
            hooksValid=false;
            warn("hook registry "+method,t);
        }
    }

    // Uses reflection to remain safe if a particular Vector build lacks this
    // optional legacy API. This never writes firmware, deoptimizes Android
    // framework classes, or changes the OEM launcher APK on disk.
    private static void deoptKnownCaller(ClassLoader loader,String className,String methodName) {
        try {
            Class<?> cls=Class.forName(className,false,loader);
            Method api=XposedBridge.class.getDeclaredMethod("deoptimizeMethod",Member.class);
            api.setAccessible(true);
            int count=0;
            for(Method m : cls.getDeclaredMethods()) {
                if(!m.getName().equals(methodName))continue;
                m.setAccessible(true);
                api.invoke(null,m);
                count++;
            }
            XposedBridge.log("APPLLP7FullGridV16: deopt "+cls.getSimpleName()+"."+methodName+" count="+count);
        } catch(NoSuchMethodException e) {
            XposedBridge.log("APPLLP7FullGridV16: deopt API unavailable; continuing with normal hooks");
        } catch(Throwable t) {
            XposedBridge.log("APPLLP7FullGridV16: deopt "+methodName+" failed: "+t.getClass().getName());
        }
    }

    private static void warn(String phase,Throwable t) {
        if(loggedError)return;
        loggedError=true;
        XposedBridge.log("APPLLP7FullGridV16: " + phase + " failed; disable module if grid misbehaves");
        XposedBridge.log(t);
    }
}
